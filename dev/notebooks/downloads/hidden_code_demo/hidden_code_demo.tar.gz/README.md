# hidden_code_demo — local inspection

This directory contains untrusted notebook code. Verify the files before opening them.
Installing the environment may execute package build scripts; opening the notebook in live mode
may execute arbitrary code.

Verify the downloaded files:

```sh
sha256sum -c SHA256SUMS
```

Inspect without starting a worker or executing cells:

```julia
using KaimonSlate
KaimonSlate.serve_notebook("hidden_code_demo.jl"; inactive = true)
```

## 1. Isolated container (recommended)

This keeps notebook execution out of the host, but package installation still executes code in
the container:

```sh
podman run --rm -it -p 8765:8765 -v "$PWD:/work:Z" -w /work julia:1.12 \
  julia --project=. -e 'using Pkg; Pkg.instantiate(); using KaimonSlate; KaimonSlate.serve_notebook("hidden_code_demo.jl"; host="0.0.0.0")'
```

## 2. Pinned host environment

This uses the published project and manifest, but runs package build scripts and notebook code
with your host account's permissions:

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. -e 'using KaimonSlate; KaimonSlate.serve_notebook("hidden_code_demo.jl")'
```

## 3. Native application

Installing and opening the application executes code with your host account's permissions:

```sh
julia -e 'using Pkg; Pkg.Registry.add(Pkg.Registry.RegistrySpec(url="https://github.com/kahliburke/SlateRegistry")); Pkg.Apps.add("KaimonSlate")'
slate --own hidden_code_demo.jl
```
